import sys
import random

inFile = sys.argv[1]

with open(inFile) as f:
	original = f.read()
f.close()

alphabet = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
cipher = alphabet.copy()
random.shuffle(cipher)

monoalphabet_cipher = dict(zip(alphabet, cipher))
inverse_cipher = {}
for key, value in monoalphabet_cipher.items():
	inverse_cipher[value] = key

l = []

for x in original:
	l.extend(monoalphabet_cipher.get(x, x))

encrypted = "".join(l)

i = []

for y in encrypted:
	i.extend(inverse_cipher.get(y, y))

decrypted = "".join(i)

print("This one is original: ", original)
print("This one is after encrypted: ", encrypted)
print("This one is after decrypted: ", decrypted)

print("This is key: ", monoalphabet_cipher)
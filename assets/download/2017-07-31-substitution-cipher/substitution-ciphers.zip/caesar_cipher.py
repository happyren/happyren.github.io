import sys

inFile = sys.argv[1]
rotateDistance = int(sys.argv[2])

with open(inFile) as f:
	cipher = f.read()
f.closed

l = []

for c in cipher:
	if 65 <= ord(c) <= 90:
		v = (ord(c) - 65 + rotateDistance) % 26 + 65
	elif 97 <= ord(c) <= 122:
		v = (ord(c) - 97 + rotateDistance) % 26 + 97
	elif 48 <= ord(c) <= 57:
		v = (ord(c) - 48 + rotateDistance) % 10 + 48
	else:
		v = ord(c)
	p = chr(v)
	l.extend(p)

outFile = "".join(l)

print(outFile)